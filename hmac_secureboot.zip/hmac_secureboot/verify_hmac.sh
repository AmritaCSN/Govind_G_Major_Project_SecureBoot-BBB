#!/bin/bash

KEY=$(cat hmac.key)

echo "Enter image filename:"
read IMAGE

if [ ! -f "$IMAGE" ]; then
    echo "File not found!"
    exit 1
fi

STORED=$(cut -d' ' -f2 kernel.hmac)

CURRENT=$(openssl dgst -sha256 -hmac "$KEY" "$IMAGE" | awk '{print $2}')

echo ""
echo "Stored HMAC : $STORED"
echo "Current HMAC: $CURRENT"
echo ""

if [ "$STORED" = "$CURRENT" ]; then
    echo "HMAC Verification SUCCESS"
    echo "Kernel image is authentic."
else
    echo "HMAC Verification FAILED"
    echo "Tampered kernel detected!"
fi
